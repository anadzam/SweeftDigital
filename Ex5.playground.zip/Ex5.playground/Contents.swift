import UIKit

func countVariants(_ stairsCount: Int) -> Int {
    var numofWays = [0,1,2]
    
    //case when count variants is same as num of stairs
    if stairsCount < 3 {
        return numofWays[stairsCount]
    }
    
    for i in 3...stairsCount {
        //reaching n stairs has formula ways(n)=ways(n-1)+ways(n-2)
        numofWays.append(numofWays[i - 1] + numofWays[i - 2])
    }
    return numofWays[stairsCount]
    
}

var input = 4
countVariants(input)
    
    
 


