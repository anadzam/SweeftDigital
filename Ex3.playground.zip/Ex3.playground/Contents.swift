import UIKit

func smallestInt(array: inout [Int]) -> Int {
    //sort the array from lowest to highest with only positive integers
    let positiveInt = array.filter { $0 > 0 }.sorted()
   
    var x = 1
    
    //compare smallest integer grater than 0 to the values of array
    for value in positiveInt {
        if (x < value) {
            return x
        }
        x = value + 1
    }
    return x
    
}

var input = [-1,9,2,0,1,2,4,5,23]
smallestInt(array: &input)
