import UIKit

func isProperly(_ string: String) -> Bool {
    var properly = 0
    //checking if string contains balanced characters
    for char in string {
        if char == "(" {
            properly += 1
        }else if char == ")" {
            properly -= 1
        }
    }
    let result = (properly == 0)
    return result
}

var input = "((()))"
isProperly(input)
