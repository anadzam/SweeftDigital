import UIKit

var coinChangeArray = [1,5,10,20,50]
var length = coinChangeArray.count
var lastIndex = length - 1

func minSplit(amount: inout Int) -> Int {
    var result = [Int]()
    
    for i in stride(from: lastIndex, through: 0, by: -1) {
        //comparing the amount of money to split in cents to the coins of array
        while (amount >= coinChangeArray[i]) {
            //updating the remaining amount
            amount -= coinChangeArray[i]
            //append the compared coin to the empty array of results
            result.append(coinChangeArray[i])
        }
    }
    for i in stride(from: 0, to: result.count, by: 1) {
     print(result[i])
    }
   
    return result.count
}

var input = 60
minSplit(amount: &input)
