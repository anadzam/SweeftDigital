import UIKit

func isPalindrome(text: String) -> Bool {
    //since we need to check text not a single word, we need to eliminate spaces
    let textWithoutSpaces = text.replacingOccurrences(of: " ", with: "").lowercased()
    //comparing reversed version to the original one
    return textWithoutSpaces.reversed() == Array(textWithoutSpaces)
  
}

isPalindrome(text: "anna ANNA Anna")

