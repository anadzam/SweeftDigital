import UIKit

let start = CFAbsoluteTimeGetCurrent()
struct Queue{
    
    var items:[String] = []
    mutating func enqueue(_ element: String)
        {
            items.append(element)
        }
    mutating func dequeue() -> String?
    {
        if items.isEmpty {
            return nil
        }
        else{
            let tempElement = items.first
            items.remove(at: 0)
            return tempElement
        }
    }
    
}
var queue = Queue()

queue.enqueue("Apple")
queue.enqueue("Banana")
queue.enqueue("Avocado")
queue.dequeue()

print(queue)

let diff = CFAbsoluteTimeGetCurrent() - start
print("Took \(diff) seconds")
